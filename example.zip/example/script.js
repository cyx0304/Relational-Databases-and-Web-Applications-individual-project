var idList = ["CEU6500000001", "CEU7000000001", "CEU6000000001","CEU1000000001", "CEU2000000001",
  "CEU2000000001","CEU3000000001","CEU3100000001","CEU5000000001", "CEU5500000001"]
var token = "9f2956a7a4f246f58abf690ac5c2df7e"
var axis = []
for (let i=0;i<3;i++){
  for (let j=1;j<13;j++){
    if (i==2 && j==12){ break }
    axis.push (j + '/' + (2019+i))
  }
}

var value = []
var getData = false
for (let i=0;i<idList.length;i++){
  const xhr = new XMLHttpRequest()
  url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
    +idList[i]+"?registrationkey="+token+"&catalog=true"
  xhr.open("GET", url, false)
  xhr.onreadystatechange = function(){
    if (xhr.readyState === xhr.DONE) {
      let obj = JSON.parse(xhr.responseText).Results.series[0].data
      let tag = JSON.parse(xhr.responseText).Results.series[0].catalog.commerce_industry
      let temp = []
      for (let i=obj.length-1;i>=0;i--){
        temp.push(Number(obj[i].value))
      }
      value.push({
        id: tag,
        data: temp
      })

      getData = true
    }
  }
  xhr.send()
}



//    console.log("labels");
//    console.log(labels);

// These are colors from chart.js utils
    const CHART_COLORS = {
      red: 'rgb(255, 99, 132)',
      orange: 'rgb(255, 159, 64)',
      yellow: 'rgb(255, 205, 86)',
      green: 'rgb(75, 192, 192)',
      blue: 'rgb(54, 162, 235)',
      purple: 'rgb(153, 102, 255)',
      grey: 'rgb(201, 203, 207)',
      brown: 'rgb(165, 42,42)',
      klein: 'rgb(0, 47, 167)',
      sand: 'rgb(204, 197, 143)'
    };
//    console.dir(CHART_COLORS);

    const CHART_COLORS_50_Percent = {
      red: 'rgba(255, 99, 132, 0.5)',
      orange: 'rgba(255, 159, 64, 0.5)',
      yellow: 'rgba(255, 205, 86, 0.5)',
      green: 'rgba(75, 192, 192, 0.5)',
      blue: 'rgba(54, 162, 235, 0.5)',
      purple: 'rgba(153, 102, 255, 0.5)',
      grey: 'rgba(201, 203, 207, 0.5)',
      brown: 'rgb(165, 42,42, 0.5)',
      klein: 'rgb(0, 47, 167, 0.5',
      sand: 'rgb(204,197,143)'
    };
//    console.log(CHART_COLORS_50_Percent);
//    end utils

    const data = {
      labels: axis,
      datasets: [
        {
          label: value[0].id,
          data: value[0].data,
          borderColor: CHART_COLORS.red,
          backgroundColor: CHART_COLORS_50_Percent.red,
          hidden: true
        },
        {
          label: value[1].id,
          data: value[1].data,
          borderColor: CHART_COLORS.blue,
          backgroundColor: CHART_COLORS_50_Percent.blue,
          hidden: true
        },
        {
          label: value[2].id,
          data: value[2].data,
          borderColor: CHART_COLORS.orange,
          backgroundColor: CHART_COLORS_50_Percent.orange,
          hidden: true
        },
        {
          label: value[3].id,
          data: value[3].data,
          borderColor: CHART_COLORS.yellow,
          backgroundColor: CHART_COLORS_50_Percent.yellow,
          hidden: true
        },
        {
          label: value[4].id,
          data: value[4].data,
          borderColor: CHART_COLORS.green,
          backgroundColor: CHART_COLORS_50_Percent.green,
          hidden: true
        },
        {
          label: value[5].id,
          data: value[5].data,
          borderColor: CHART_COLORS.grey,
          backgroundColor: CHART_COLORS_50_Percent.grey,
          hidden: true
        },
        {
          label: value[6].id,
          data: value[6].data,
          borderColor: CHART_COLORS.red,
          backgroundColor: CHART_COLORS_50_Percent.purple,
          hidden: true
        },
        {
          label: value[7].id,
          data: value[7].data,
          borderColor: CHART_COLORS.red,
          backgroundColor: CHART_COLORS_50_Percent.brown,
          hidden: true
        },
        {
          label: value[8].id,
          data: value[8].data,
          borderColor: CHART_COLORS.red,
          backgroundColor: CHART_COLORS_50_Percent.klein,
          hidden: true
        },
        {
          label: value[9].id,
          data: value[9].data,
          borderColor: CHART_COLORS.red,
          backgroundColor: CHART_COLORS_50_Percent.sand,
          hidden: true
        },
      ]
    };
  //  console.dir(data);

    const config = {
      type: 'line',
      data: data,
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Number of Employees in Thousands'
          }
        }
      }
    };
//    console.log(config);

    const myChart = new Chart(
      document.getElementById('myChart'),
        config);
//    console.dir(myChart);
//    console.log("Ending");
